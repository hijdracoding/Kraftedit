'use client'

import { useEffect, useRef, useCallback, useState } from 'react'
import { SkinViewer, WalkingAnimation, IdleAnimation } from 'skinview3d'
import type { BodyPart, BodyFace } from '@/types/skin'
import { cn } from '@/lib/utils'

interface SkinViewer3DProps {
  skinUrl: string | null
  className?: string
  width?: number
  height?: number
  animation?: 'walk' | 'idle' | 'none'
  autoRotate?: boolean
  selectedPart?: BodyPart | null
  selectedFace?: BodyFace
  onPartClick?: (part: BodyPart) => void
  showControls?: boolean
}

type CameraPos = { x: number; y: number; z: number; target: { x: number; y: number; z: number } }

/**
 * skinview3d coordinate system:
 * - Model center is at origin (0, 0, 0)
 * - Y axis: up/down, model spans roughly Y=-12 (feet) to Y=+12 (head top)
 * - X axis: left/right, +X is model's left side (viewer's right)
 * - Z axis: front/back, +Z faces the viewer (front)
 * 
 * Body part centers (approximate Y positions from model center):
 * - Head center: Y = +10 (8 pixels tall, top at +12, center at +10)
 * - Body center: Y = +2 (12 pixels tall, from +8 to -4, center at +2)  
 * - Arms center: Y = +2 (same height as body)
 * - Legs center: Y = -8 (12 pixels tall, from -4 to -12, center at -8)
 * 
 * X offsets for arms/legs:
 * - Right arm/leg: X = -6 (model's right = viewer's left = negative X)
 * - Left arm/leg: X = +6 (model's left = viewer's right = positive X)
 */
const PART_CONFIG: Record<BodyPart, { y: number; x: number; dist: number }> = {
  head:      { y: 10,  x: 0,  dist: 20 },
  body:      { y: 2,   x: 0,  dist: 25 },
  right_arm: { y: 2,   x: -6, dist: 20 },
  left_arm:  { y: 2,   x: 6,  dist: 20 },
  right_leg: { y: -8,  x: -2, dist: 20 },
  left_leg:  { y: -8,  x: 2,  dist: 20 },
}

/**
 * Build camera position that centers the selected body part in the viewport.
 * Camera is positioned at `dist` units away from the part center,
 * looking directly at the part center (target).
 */
function buildCameraPos(part: BodyPart, face: BodyFace): CameraPos {
  const { y: py, x: px, dist } = PART_CONFIG[part]
  // Target is exactly the center of the body part
  const target = { x: px, y: py, z: 0 }

  switch (face) {
    case 'front':
      return { x: px, y: py, z: dist, target }
    case 'back':
      return { x: px, y: py, z: -dist, target }
    case 'left':
      // Camera to model's left (+X direction)
      return { x: px + dist, y: py, z: 0, target }
    case 'right':
      // Camera to model's right (-X direction)
      return { x: px - dist, y: py, z: 0, target }
    case 'top':
      return { x: px, y: py + dist, z: 0.01, target }
    case 'bottom':
      return { x: px, y: py - dist, z: 0.01, target }
    default:
      return { x: px, y: py, z: dist, target }
  }
}

// Default Steve skin from Minecraft textures (reliable source)
const DEFAULT_SKIN = 'https://textures.minecraft.net/texture/1a4af718455d4aab528e7a61f86fa25e6a369d1768dcb13f7df319a713eb810b'

export function SkinViewer3D({
  skinUrl,
  className,
  width,
  height,
  animation = 'walk',
  autoRotate = true,
  selectedPart,
  selectedFace = 'front',
  onPartClick,
  showControls = true,
}: SkinViewer3DProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const viewerRef = useRef<SkinViewer | null>(null)
  const animFrameRef = useRef<number | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  // Start with non-zero defaults so initViewer can run immediately
  const [dimensions, setDimensions] = useState({ width: width || 0, height: height || 0 })

  // Measure container and update dimensions
  useEffect(() => {
    if (width && height) {
      setDimensions({ width, height })
      return
    }

    const measure = () => {
      if (!containerRef.current) return
      const w = containerRef.current.offsetWidth
      const h = containerRef.current.offsetHeight
      if (w > 0 && h > 0) {
        setDimensions({ width: w, height: h })
      }
    }

    measure()

    const ro = new ResizeObserver(measure)
    if (containerRef.current) ro.observe(containerRef.current)
    return () => ro.disconnect()
  }, [width, height])

  const initViewer = useCallback(async () => {
    if (!canvasRef.current || dimensions.width === 0 || dimensions.height === 0) return

    if (viewerRef.current) {
      viewerRef.current.dispose()
    }

    try {
      const viewer = new SkinViewer({
        canvas: canvasRef.current,
        width: dimensions.width,
        height: dimensions.height,
      })

      viewer.fov = 50
      viewer.zoom = 0.9
      viewer.controls.enableRotate = true
      viewer.controls.enableZoom = showControls
      viewer.controls.enablePan = false

      if (animation === 'walk') {
        viewer.animation = new WalkingAnimation()
        viewer.animation.speed = 0.6
      } else if (animation === 'idle') {
        viewer.animation = new IdleAnimation()
        viewer.animation.speed = 0.5
      }

      viewerRef.current = viewer

      // Load skin separately to properly catch errors
      try {
        await viewer.loadSkin(skinUrl || DEFAULT_SKIN)
      } catch {
        // Fallback to default skin if provided URL fails
        try {
          await viewer.loadSkin(DEFAULT_SKIN)
        } catch {
          // Silently fail if even default skin fails
        }
      }

      setIsLoaded(true)
    } catch (error) {
      console.error('Failed to initialize skin viewer:', error)
    }
  }, [skinUrl, dimensions.width, dimensions.height, animation, showControls])

  // Toggle autoRotate reactively without re-creating the viewer
  useEffect(() => {
    if (!viewerRef.current) return
    viewerRef.current.autoRotate = autoRotate
    if (autoRotate) viewerRef.current.autoRotateSpeed = 1
  }, [autoRotate, isLoaded])

  useEffect(() => {
    initViewer()
    return () => {
      viewerRef.current?.dispose()
    }
  }, [initViewer])

  // Update viewer size when dimensions change
  useEffect(() => {
    if (viewerRef.current && dimensions.width > 0 && dimensions.height > 0) {
      viewerRef.current.width = dimensions.width
      viewerRef.current.height = dimensions.height
    }
  }, [dimensions])

  // Update skin texture when URL changes without re-initialising
  useEffect(() => {
    if (viewerRef.current && skinUrl) {
      viewerRef.current.loadSkin(skinUrl).catch(() => {
        // Silently fail - skin will keep current texture
      })
    }
  }, [skinUrl])

  // Animate camera smoothly to the target body part position
  useEffect(() => {
    if (!viewerRef.current || !selectedPart) return

    const viewer = viewerRef.current
    const pos = buildCameraPos(selectedPart, selectedFace)

    // Stop any in-progress animation
    if (animFrameRef.current !== null) {
      cancelAnimationFrame(animFrameRef.current)
      animFrameRef.current = null
    }

    viewer.autoRotate = false

    const startCamX = viewer.camera.position.x
    const startCamY = viewer.camera.position.y
    const startCamZ = viewer.camera.position.z
    const startTgtX = viewer.controls.target.x
    const startTgtY = viewer.controls.target.y
    const startTgtZ = viewer.controls.target.z
    const startZoom = viewer.zoom

    const DURATION = 500 // ms
    const startTime = performance.now()

    function easeInOut(t: number) {
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t
    }

    function step(now: number) {
      const raw = Math.min((now - startTime) / DURATION, 1)
      const t = easeInOut(raw)

      viewer.camera.position.set(
        startCamX + (pos.x - startCamX) * t,
        startCamY + (pos.y - startCamY) * t,
        startCamZ + (pos.z - startCamZ) * t
      )
      viewer.controls.target.set(
        startTgtX + (pos.target.x - startTgtX) * t,
        startTgtY + (pos.target.y - startTgtY) * t,
        startTgtZ + (pos.target.z - startTgtZ) * t
      )
      viewer.zoom = startZoom + (1.5 - startZoom) * t
      viewer.controls.update()

      if (raw < 1) {
        animFrameRef.current = requestAnimationFrame(step)
      } else {
        animFrameRef.current = null
      }
    }

    animFrameRef.current = requestAnimationFrame(step)

    return () => {
      if (animFrameRef.current !== null) {
        cancelAnimationFrame(animFrameRef.current)
        animFrameRef.current = null
      }
    }
  }, [selectedPart, selectedFace])

  return (
    <div ref={containerRef} className={cn('relative', className)}>
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-obsidian-card">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-neon border-t-transparent" />
        </div>
      )}
      <canvas
        ref={canvasRef}
        className="block h-full w-full"
      />
    </div>
  )
}

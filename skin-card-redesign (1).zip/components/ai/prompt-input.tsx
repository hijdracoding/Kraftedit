'use client'

import { useState, useRef } from 'react'
import { Upload, Image as ImageIcon, Type } from 'lucide-react'
import { cn } from '@/lib/utils'

interface PromptInputProps {
  onSubmit: (prompt: string, imageFile?: File) => void
  isLoading?: boolean
  placeholder?: string
  className?: string
}

export function PromptInput({
  onSubmit,
  isLoading = false,
  placeholder = 'Describe your skin...',
  className,
}: PromptInputProps) {
  const [prompt, setPrompt] = useState('')
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim() && !selectedImage) return
    onSubmit(prompt, selectedImage || undefined)
  }

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedImage(file)
      const url = URL.createObjectURL(file)
      setPreviewUrl(url)
    }
  }

  const removeImage = () => {
    setSelectedImage(null)
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
      setPreviewUrl(null)
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  return (
    <form onSubmit={handleSubmit} className={cn('space-y-3', className)}>
      {/* Text Input */}
      <div className="rounded-xl bg-obsidian-card p-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder={placeholder}
          rows={3}
          disabled={isLoading}
          className="w-full resize-none bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none"
        />

        {/* Image Preview */}
        {previewUrl && (
          <div className="relative mt-3 inline-block">
            <img
              src={previewUrl}
              alt="Selected reference"
              className="h-20 w-20 rounded-lg object-cover"
            />
            <button
              type="button"
              onClick={removeImage}
              className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-destructive text-destructive-foreground"
            >
              ×
            </button>
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-3 flex items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-obsidian-elevated hover:text-foreground disabled:opacity-50"
            title="Upload reference image"
          >
            <Upload className="h-5 w-5" />
          </button>
          <button
            type="button"
            disabled={isLoading}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-obsidian-elevated hover:text-foreground disabled:opacity-50"
            title="Use existing skin as reference"
          >
            <ImageIcon className="h-5 w-5" />
          </button>
          <button
            type="button"
            disabled={isLoading}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-obsidian-elevated hover:text-foreground disabled:opacity-50"
            title="Negative prompt"
          >
            <span className="text-lg font-bold">N</span>
          </button>
        </div>
      </div>

      {/* Generate Button */}
      <button
        type="submit"
        disabled={isLoading || (!prompt.trim() && !selectedImage)}
        className={cn(
          'flex h-14 w-full items-center justify-center gap-2 rounded-xl text-lg font-bold tracking-wide transition-all',
          isLoading || (!prompt.trim() && !selectedImage)
            ? 'cursor-not-allowed bg-obsidian-elevated text-muted-foreground'
            : 'bg-neon text-obsidian neon-pulse hover:bg-neon-bright'
        )}
      >
        {isLoading ? (
          <>
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-current border-t-transparent" />
            Generating...
          </>
        ) : (
          <>
            Generate
            <svg
              className="h-5 w-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 3l14 9-14 9V3z"
              />
            </svg>
          </>
        )}
      </button>
    </form>
  )
}

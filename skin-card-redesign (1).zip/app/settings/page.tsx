'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { 
  ArrowLeft, 
  Trash2, 
  LogOut,
  Moon,
  Sun,
  Globe,
  Lock,
  Camera
} from 'lucide-react'
import { BottomNav } from '@/components/layout/bottom-nav'
import { useTheme } from '@/components/providers/theme-provider'
import { cn } from '@/lib/utils'

// Mock user data - replace with real auth context
const MOCK_USER = {
  id: 'user-001',
  username: 'AETHER_BLADE',
  bio: 'Professional skin architect & digital obsidian artist.',
  avatar: 'https://mc-heads.net/avatar/Steve/128',
}

export default function SettingsPage() {
  const router = useRouter()
  const { theme, toggleTheme } = useTheme()
  const isDark = theme === 'dark'
  const [username, setUsername] = useState(MOCK_USER.username)
  const [bio, setBio] = useState(MOCK_USER.bio)
  const [avatar, setAvatar] = useState(MOCK_USER.avatar)
  const [publicProfile, setPublicProfile] = useState(true)
  const [hasChanges, setHasChanges] = useState(false)

  // Track changes
  useEffect(() => {
    const changed = 
      username !== MOCK_USER.username || 
      bio !== MOCK_USER.bio ||
      avatar !== MOCK_USER.avatar
    setHasChanges(changed)
  }, [username, bio, avatar])

  const handleSave = () => {
    // In real app: save to database
    console.log('Saving:', { username, bio, avatar, darkMode, publicProfile })
    setHasChanges(false)
  }

  const handleAvatarChange = () => {
    // In real app: open file picker
    console.log('Change avatar')
  }

  const handleLogout = () => {
    // In real app: clear auth state, redirect to login
    router.push('/auth/login')
  }

  const handleDeleteAccount = () => {
    // In real app: show confirmation dialog, then delete
    if (confirm('Weet je zeker dat je je account wilt verwijderen? Dit kan niet ongedaan worden gemaakt.')) {
      router.push('/auth/login')
    }
  }

  return (
    <div className="flex min-h-[100dvh] flex-col bg-background pb-16">
      {/* Header */}
      <header className="shrink-0 border-b border-border bg-obsidian-surface/95 backdrop-blur-lg">
        <div className="flex h-11 items-center justify-between px-3">
          <button
            onClick={() => router.back()}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-obsidian-elevated hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <h1 className="text-xs font-bold tracking-wide">
            <span className="text-neon">Settings</span>
          </h1>
          {hasChanges ? (
            <button
              onClick={handleSave}
              className="rounded-lg bg-neon px-3 py-1.5 text-xs font-bold text-obsidian transition-colors hover:bg-neon-bright"
            >
              Save
            </button>
          ) : (
            <div className="w-8" />
          )}
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-auto">
        {/* Profile Section */}
        <section className="border-b border-border bg-obsidian-surface p-4">
          <h3 className="mb-3 text-xs font-semibold tracking-wide text-muted-foreground">
            Profile
          </h3>
          
          {/* Avatar */}
          <div className="mb-4 flex items-center gap-4">
            <div className="relative">
              <div className="h-16 w-16 overflow-hidden rounded-full border-2 border-neon bg-obsidian-elevated">
                <Image
                  src={avatar}
                  alt={username}
                  width={64}
                  height={64}
                  className="h-full w-full object-cover"
                />
              </div>
              <button 
                onClick={handleAvatarChange}
                className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-neon text-obsidian transition-colors hover:bg-neon-bright"
              >
                <Camera className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Profile picture</p>
              <p className="text-xs text-muted-foreground">Tap icon to change</p>
            </div>
          </div>

          {/* Username */}
          <div className="mb-3">
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
              Username
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full rounded-lg border border-border bg-obsidian-card px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-neon focus:outline-none focus:ring-1 focus:ring-neon"
              placeholder="Enter username"
            />
          </div>

          {/* Bio */}
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
              Bio
            </label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              className="w-full resize-none rounded-lg border border-border bg-obsidian-card px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-neon focus:outline-none focus:ring-1 focus:ring-neon"
              placeholder="Tell others about yourself"
            />
          </div>
        </section>

        {/* Preferences Section */}
        <section className="border-b border-border bg-obsidian-surface p-4">
          <h3 className="mb-3 text-xs font-semibold tracking-wide text-muted-foreground">
            Preferences
          </h3>
          
          <div className="space-y-2">
            {/* Dark Mode Toggle */}
            <div className="flex items-center justify-between rounded-xl bg-obsidian-card p-3">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-obsidian-elevated text-muted-foreground">
                  {isDark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Dark Mode</p>
                  <p className="text-xs text-muted-foreground">
                    {isDark ? 'Dark theme active' : 'Light theme active'}
                  </p>
                </div>
              </div>
              <button
                onClick={toggleTheme}
                className={cn(
                  'relative h-6 w-11 rounded-full transition-colors',
                  isDark ? 'bg-neon' : 'bg-obsidian-elevated'
                )}
              >
                <div
                  className={cn(
                    'absolute top-1 h-4 w-4 rounded-full bg-white transition-transform',
                    isDark ? 'translate-x-6' : 'translate-x-1'
                  )}
                />
              </button>
            </div>

            {/* Profile Visibility Toggle */}
            <div className="flex items-center justify-between rounded-xl bg-obsidian-card p-3">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-obsidian-elevated text-muted-foreground">
                  {publicProfile ? <Globe className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Public Profile</p>
                  <p className="text-xs text-muted-foreground">
                    {publicProfile ? 'Everyone can see your profile' : 'Only you can see your profile'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setPublicProfile(!publicProfile)}
                className={cn(
                  'relative h-6 w-11 rounded-full transition-colors',
                  publicProfile ? 'bg-neon' : 'bg-obsidian-elevated'
                )}
              >
                <div
                  className={cn(
                    'absolute top-1 h-4 w-4 rounded-full bg-white transition-transform',
                    publicProfile ? 'translate-x-6' : 'translate-x-1'
                  )}
                />
              </button>
            </div>
          </div>
        </section>

        {/* Account Actions */}
        <section className="p-4">
          <h3 className="mb-3 text-xs font-semibold tracking-wide text-destructive">
            Account
          </h3>
          
          <div className="space-y-2">
            {/* Logout */}
            <button
              onClick={handleLogout}
              className="flex w-full items-center gap-3 rounded-xl bg-obsidian-card p-3 transition-colors hover:bg-obsidian-elevated active:scale-[0.99]"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-obsidian-elevated text-muted-foreground">
                <LogOut className="h-4 w-4" />
              </div>
              <p className="text-sm font-medium text-foreground">Log out</p>
            </button>

            {/* Delete Account */}
            <button
              onClick={handleDeleteAccount}
              className="flex w-full items-center gap-3 rounded-xl bg-obsidian-card p-3 transition-colors hover:bg-destructive/10 active:scale-[0.99]"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-destructive/20 text-destructive">
                <Trash2 className="h-4 w-4" />
              </div>
              <div className="text-left">
                <p className="text-sm font-medium text-destructive">Delete account</p>
                <p className="text-xs text-muted-foreground">Permanently delete your account and data</p>
              </div>
            </button>
          </div>
        </section>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

'use client'

import { useState, useMemo, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Settings, Plus, Eye, Globe, Lock, Download, Heart } from 'lucide-react'
import { BottomNav } from '@/components/layout/bottom-nav'
import { SkinCard } from '@/components/gallery/skin-card'
import { mockSkins } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

const MOCK_USER = {
  id: 'user-001',
  username: 'AETHER_BLADE',
  avatar: 'https://mc-heads.net/avatar/Steve/128',
  skinsCreated: 124,
  totalDownloads: 85200,
  followers: 12400,
}

type FilterOption = 'all' | 'published' | 'drafts'

export default function ProfilePage() {
  const [filterBy, setFilterBy] = useState<FilterOption>('all')
  const [savedSkins, setSavedSkins] = useState<any[]>([])

  // Load saved skins from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('savedSkins')
    if (stored) {
      setSavedSkins(JSON.parse(stored))
    }
  }, [])

  // Combine mock skins with user's saved skins
  const userSkins = useMemo(() => {
    const mockUserSkins = mockSkins.filter((skin) => skin.creatorId === MOCK_USER.id)
    return [...savedSkins.map(s => ({ ...s, creatorId: MOCK_USER.id, creator: MOCK_USER.username, likes: 0, downloads: 0 })), ...mockUserSkins]
  }, [savedSkins])

  const filteredSkins = useMemo(() => {
    if (filterBy === 'published') {
      return userSkins.filter((skin) => skin.published)
    } else if (filterBy === 'drafts') {
      return userSkins.filter((skin) => !skin.published)
    }
    return userSkins
  }, [filterBy, userSkins])

  const filterOptions: { value: FilterOption; label: string; icon: typeof Globe }[] = [
    { value: 'all', label: 'All', icon: Eye },
    { value: 'published', label: 'Public', icon: Globe },
    { value: 'drafts', label: 'Private', icon: Lock },
  ]

  return (
    <div className="flex min-h-[100dvh] flex-col bg-background pb-16">
      {/* Header */}
      <header className="shrink-0 border-b border-border bg-obsidian-surface/95 backdrop-blur-lg">
        <div className="flex h-11 items-center justify-between px-3">
          <div className="w-8" />
          <h1 className="text-xs font-bold tracking-wide">
            <span className="text-neon">My</span>
            <span className="text-foreground"> Profile</span>
          </h1>
          <Link 
            href="/settings"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-obsidian-elevated hover:text-foreground"
          >
            <Settings className="h-4 w-4" />
          </Link>
        </div>
      </header>

      {/* Profile Card */}
      <section className="shrink-0 border-b border-border bg-obsidian-surface px-4 py-4">
        <div className="flex items-center gap-4">
          {/* Avatar */}
          <div className="relative">
            <div className="h-16 w-16 overflow-hidden rounded-full border-2 border-neon bg-obsidian-elevated">
              <Image
                src={MOCK_USER.avatar}
                alt={MOCK_USER.username}
                width={64}
                height={64}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full border-2 border-obsidian-surface bg-neon" />
          </div>

          {/* Info */}
          <div className="flex-1">
            <h2 className="text-base font-bold text-foreground">{MOCK_USER.username}</h2>
            <div className="mt-1 flex items-center gap-4 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1">
                <Eye className="h-3 w-3" />
                {MOCK_USER.skinsCreated} skins
              </span>
              <span className="flex items-center gap-1">
                <Download className="h-3 w-3" />
                {(MOCK_USER.totalDownloads / 1000).toFixed(1)}k
              </span>
              <span className="flex items-center gap-1">
                <Heart className="h-3 w-3" />
                {(MOCK_USER.followers / 1000).toFixed(1)}k
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Filter & Create */}
      <section className="shrink-0 border-b border-border bg-obsidian-surface px-3 py-2">
        <div className="flex items-center gap-2">
          {/* Filter Pills */}
          <div className="flex flex-1 gap-1.5">
            {filterOptions.map(({ value, label, icon: Icon }) => (
              <button
                key={value}
                onClick={() => setFilterBy(value)}
                className={cn(
                  'flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[11px] font-semibold tracking-wide transition-all',
                  filterBy === value
                    ? 'pill-selected'
                    : 'pill-unselected'
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {label}
              </button>
            ))}
          </div>

          {/* Create Button */}
          <Link
            href="/editor"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-neon text-obsidian transition-colors hover:bg-neon-bright"
          >
            <Plus className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Skins Grid */}
      <main className="flex-1 overflow-auto p-3">
        {filteredSkins.length > 0 ? (
          <div className="grid grid-cols-2 gap-2">
            {filteredSkins.map((skin) => (
              <SkinCard key={skin.id} skin={skin} />
            ))}
          </div>
        ) : (
          <div className="flex h-full flex-col items-center justify-center">
            <p className="text-sm text-muted-foreground">No skins yet</p>
            <Link
              href="/editor"
              className="mt-3 flex items-center gap-2 rounded-lg bg-neon px-4 py-2 text-xs font-semibold text-obsidian transition-colors hover:bg-neon-bright"
            >
              <Plus className="h-4 w-4" />
              Create Your First Skin
            </Link>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}
